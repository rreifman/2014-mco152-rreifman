package reifman.iss;

public class Result {
	
	private Geometry geometry;

	public Geometry getGeometry() {
		return geometry;
	}

}
