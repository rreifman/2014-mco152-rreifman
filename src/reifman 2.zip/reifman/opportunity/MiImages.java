package reifman.opportunity;

public class MiImages {
	
	private Images[] images;
	
	public Images[] getImages(){
		return images;
	}

}
