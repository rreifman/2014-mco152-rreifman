package reifman.opportunity;

public class PCamImages {
	
	private Images[] images;
	
	public Images[] getImages(){
		return images;
	}

}
