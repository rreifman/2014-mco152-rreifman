package reifman.opportunity;

public class Images {
	
	private String url;
	
	public String getUrl(){
		return url;
	}

}
