package reifman.iss;

public class LonLat {
	
	private Result[] results;

	public Result[] getResults() {
		return results;
	}
	

}
