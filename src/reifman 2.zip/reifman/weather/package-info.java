/**
 * 
 */
/**
 * @author rivkareifman
 *
 */
package reifman.weather;