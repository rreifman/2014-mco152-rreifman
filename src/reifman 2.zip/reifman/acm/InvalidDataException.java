package reifman.acm;

public class InvalidDataException extends Exception {

	private static final long serialVersionUID = 1L;


}
