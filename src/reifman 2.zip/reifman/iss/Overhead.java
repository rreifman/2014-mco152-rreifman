package reifman.iss;

public class Overhead {


	private Response[] response;
	
	public Response[] getResponse() {
		return response;
	}

	
}
