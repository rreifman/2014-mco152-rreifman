package reifman.nytimes;

public class News {
	
	private Response response;

	public Response getResponse() {
		return response;
	}
	
	

}
