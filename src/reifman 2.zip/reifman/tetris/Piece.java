package reifman.tetris;

public class Piece {

	protected Square squares[][];
	
	public Piece() {
		squares = new Square[4][4];
	}
	
	public void rotateRight(){
		
	}
	
	//public String toString(){
		
		//put 0 for filled
		//- for empty
	//}
	
	public void moveRight(){
		
	}
	
	public void moveLeft(){
		
	}
	
	public void moveDown(){
		
	}
}
