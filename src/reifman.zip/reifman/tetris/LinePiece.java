package reifman.tetris;

public class LinePiece extends Piece {

	public LinePiece(){
		super();
		
		squares[0][1] = new Square();
	}
}
