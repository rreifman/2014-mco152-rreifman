package reifman.tetris;

public class Square {


}
