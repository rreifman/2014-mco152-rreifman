/**
 * 
 */
/**
 * @author rivkareifman
 *
 */
package reifman.gameoflife;