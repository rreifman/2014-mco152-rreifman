package reifman.earthquakes;

public class Properties {
	
	private double mag;
	private String place;
	
	public double getMag() {
		return mag;
	}
	public String getPlace() {
		return place;
	}
}
