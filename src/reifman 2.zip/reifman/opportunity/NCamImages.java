package reifman.opportunity;

public class NCamImages {

	private Images[] images;
	
	public Images[] getImages(){
		return images;
	}
}
