/**
 * 
 */
/**
 * @author rivkareifman
 *
 */
package reifman.opportunity;