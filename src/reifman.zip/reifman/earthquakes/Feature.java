package reifman.earthquakes;

public class Feature {
	
	Properties properties;

	public Properties getProperties() {
		return properties;
	}
	
	
	
	

}
