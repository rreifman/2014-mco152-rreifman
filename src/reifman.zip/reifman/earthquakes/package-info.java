/**
 * 
 */
/**
 * @author rivkareifman
 *
 */
package reifman.earthquakes;