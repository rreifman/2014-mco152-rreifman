package reifman.iss;

public class Geometry {
	
	private Location location;

	public Location getLocation() {
		return location;
	}

}
