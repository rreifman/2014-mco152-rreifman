package reifman.iss;

public class Response {
	

	private int risetime;
	
	public int getRiseTime() {
		return risetime;
	}


}
