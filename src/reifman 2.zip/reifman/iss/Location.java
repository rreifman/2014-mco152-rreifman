package reifman.iss;

public class Location {


	private double lat;
	private double lng;
	
	public double getLat() {
		return lat;
	}
	public double getLng() {
		return lng;
	}
		
}
