package reifman.nytimes;

public class Multimedia {

	private String url;

	public String getUrl() {
		return url;
	}
}
