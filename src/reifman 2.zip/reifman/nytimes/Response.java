package reifman.nytimes;

public class Response {

	private Document[] docs;

	public Document[] getDocs() {
		return docs;
	}
}
