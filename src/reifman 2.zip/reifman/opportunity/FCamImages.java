package reifman.opportunity;

public class FCamImages {
	
	private Images[] images;
	
	public Images[] getImages(){
		return images;
	}

}
